package zad1;
public class Good {
    private int id;
    private double weight;

    public Good(int id, double weight) {
        this.id = id;
        this.weight = weight;
    }

    public double getWeight() {
        return weight;
    }
}
