package zad1;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.sql.*;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
class Database {

    public String url;
    public TravelData travelData;

    public Database(String url, TravelData travelData) {
        this.url = url;
        this.travelData = travelData;
    }

    public void create() {
        try (Connection connection = DriverManager.getConnection(url);
             Statement statement = connection.createStatement()) {

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS offers (" +
                    "country TEXT, departure_date TEXT, return_date TEXT, " +
                    "place TEXT, price REAL, currency_symbol TEXT)");

            for (String offerDescription : travelData.getOffersDescriptionsList("en_US", "yyyy-MM-dd")) {
                String[] parts = offerDescription.split(" ");
                String country = parts[0];
                String departureDate = parts[1];
                String returnDate = parts[2];
                String place = parts[3];
                double price = Double.parseDouble(parts[4].replace(",", ""));
                String currencySymbol = parts[5];

                String query = String.format("INSERT INTO offers VALUES ('%s', '%s', '%s', '%s', %s, '%s')",
                        country, departureDate, returnDate, place, price, currencySymbol);
                statement.executeUpdate(query);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showGui() {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Travel Offers");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

            JTable table = new JTable();
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Country");
            model.addColumn("Departure Date");
            model.addColumn("Return Date");
            model.addColumn("Place");
            model.addColumn("Price");
            model.addColumn("Currency Symbol");

            try (Connection connection = DriverManager.getConnection(url);
                 Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery("SELECT * FROM offers")) {

                while (resultSet.next()) {
                    Object[] row = {
                            resultSet.getString("country"),
                            resultSet.getString("departure_date"),
                            resultSet.getString("return_date"),
                            resultSet.getString("place"),
                            resultSet.getDouble("price"),
                            resultSet.getString("currency_symbol")
                    };
                    model.addRow(row);
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }

            table.setModel(model);

            JScrollPane scrollPane = new JScrollPane(table);
            frame.getContentPane().add(scrollPane, BorderLayout.CENTER);

            JComboBox<String> localeComboBox = new JComboBox<>(new String[]{"pl_PL", "en_US"});
            JButton refreshButton = new JButton("Refresh");
            refreshButton.addActionListener(e -> {
                String selectedLocale = (String) localeComboBox.getSelectedItem();
                List<String> offers = travelData.getOffersDescriptionsList(selectedLocale, "yyyy-MM-dd");
                model.setRowCount(0);
                for (String offer : offers) {
                    String[] parts = offer.split(" ");
                    Object[] row = {
                            parts[0], parts[1], parts[2], parts[3], Double.parseDouble(parts[4].replace(",", "")), parts[5]
                    };
                    model.addRow(row);
                }
            });

            JPanel panel = new JPanel();
            panel.add(new JLabel("Select Locale: "));
            panel.add(localeComboBox);
            panel.add(refreshButton);
            frame.getContentPane().add(panel, BorderLayout.NORTH);

            frame.setSize(800, 600);
            frame.setLocationRelativeTo(null);
            frame.setVisible(true);
        });
    }
}