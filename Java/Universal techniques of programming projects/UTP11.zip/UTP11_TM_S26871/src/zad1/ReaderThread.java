package zad1;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ReaderThread extends Thread {

    private LinkedBlockingQueue<Good> queue;
    private String fileName;
    private int count;
    public int checker=0;
    static final Good END_OF_FILE_MARKER = new Good(-1, -1);

    // Constructor
    public ReaderThread(LinkedBlockingQueue<Good> queue, String fileName) {
        this.queue = queue;
        this.fileName = fileName;
        this.count = 0;
    }

    // The run method
    public void run() {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = br.readLine()) != null) {
                String[] tokens = line.split(" ");
                if (Objects.equals(tokens[0], ""))
                {
                    break;
                }
                int id = Integer.parseInt(tokens[0]);
                double weight = Double.parseDouble(tokens[1]);
                Good good = new Good(id, weight);
                queue.put(good);
                count++;
                if (count % 200==0) {
                    checker+=count;
                    count=0;
                    System.out.println("Created " + checker + " objects");
                }
            }
            br.close();
            queue.put(END_OF_FILE_MARKER);
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}


