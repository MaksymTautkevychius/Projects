package zad1;

import java.util.concurrent.BlockingQueue;

import static zad1.ReaderThread.END_OF_FILE_MARKER;

public class SumThread extends Thread {
    public BlockingQueue<Good> queue;
    public  int count;
    public int checker=100, dl=100;

    public  double total;

    // Constructor
    public SumThread(BlockingQueue<Good> queue) {
        this.queue = queue;
        this.count = 0;
        this.total = 0;
    }

    // The run method
    public void run() {
        try {

            Good good = queue.take();

            while (good != END_OF_FILE_MARKER) {

                total += good.getWeight();

                count++;

                if (count % 100 == 0) {
                    checker+=count;
                    count=0;
                    System.out.println("Counted the weight of " + dl + " goods");
                    dl+=100;
                }

                good = queue.take();
            }

            System.out.println("The total weight of all the goods is " + total);
        } catch (InterruptedException e) {

            e.printStackTrace();
        }
    }
}
