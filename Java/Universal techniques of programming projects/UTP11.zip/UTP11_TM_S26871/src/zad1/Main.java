/**
 *
 *  @author Tautkevychius Maksym S26871
 *
 */

package zad1;

import java.util.concurrent.LinkedBlockingQueue;

public class Main {
  public static void main(String[] args) {
    LinkedBlockingQueue<Good> queue = new LinkedBlockingQueue<>(10000);
    ReaderThread reader = new ReaderThread(queue, "../Goods.txt");
    SumThread sum = new SumThread(queue);
    reader.start();
    sum.start();
  }
}
