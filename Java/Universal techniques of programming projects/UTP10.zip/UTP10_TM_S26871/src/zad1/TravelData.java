package zad1;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Scanner;

public class TravelData {
    private File dataDir;

    public TravelData(File dataDir) {
        this.dataDir = dataDir;
    }

    public List<String> getOffersDescriptionsList(String loc, String dateFormat) {
        List<String> offersDescriptions = new ArrayList<>();

        Locale locale = new Locale(loc.split("_")[0], loc.split("_")[1]);

        for (File file : dataDir.listFiles()) {
            try (Scanner scanner = new Scanner(file)) {
                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split("\t");

                    String location = new Locale(parts[0]).getDisplayCountry(locale);
                    String departureDate = formatDate(parts[2], dateFormat);
                    String returnDate = formatDate(parts[3], dateFormat);
                    String place = parts[4];
                    String price = formatPrice(parts[5]);
                    String currency = parts[6];

                    String offerDescription = String.format("%s %s %s %s %s %s",
                            location, departureDate, returnDate, place, price, currency);
                    offersDescriptions.add(offerDescription);
                }
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }

        return offersDescriptions;
    }

    private String formatDate(String date, String targetFormat) {
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat outputFormat = new SimpleDateFormat(targetFormat);

        try {
            return outputFormat.format(inputFormat.parse(date));
        } catch (ParseException e) {
            e.printStackTrace();
            return date; // return original date in case of parsing error
        }
    }

    private String formatPrice(String price) {
        return price.replace(",", " "); // remove commas from the price for formatting
    }
}
